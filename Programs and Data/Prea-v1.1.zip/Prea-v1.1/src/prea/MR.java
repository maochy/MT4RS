package prea;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import com.google.common.collect.BiMap;
import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Table;

import prea.data.structure.SparseMatrix;

public abstract class MR {
	
	/**
	 * 根据MR生成训练集与测试�?
	 * @param trainMatrix 
	 * @param inItemIds 
	 * @param inUserIds 
	 * @param userCount 
	 * @param sparseMatrix 
	 * @param loop
	 */
	public abstract void execute(String folder, String mainFolder, SparseMatrix trainMatrix, SparseMatrix testMatrix, int userCount, BiMap<Integer, String> inUserIds, BiMap<Integer, String> inItemIds);
	
	/**
	 * 根据MR的评价策略进行评价操作，保存MR评价结果
	 * @param loop
	 */
	public abstract void assertion(String mainFolder, String mrFolder, int loop);

	/**
	 *  保存数据到txt文本文件
	 * @param location
	 * @param mr_ratings
	 * @return
	 */
	protected boolean saveData(String location, ArrayList<String> mr_ratings) {
		try {
			File txt = new File(location);
			if(!txt.exists()) {
				txt.createNewFile();
			}
			BufferedWriter txtBW = new BufferedWriter(new FileWriter(txt));
			for(String str : mr_ratings) {
				txtBW.append(str + "\n");
			}
			txtBW.close();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * 读取预测结果
	 * @param location
	 * @return
	 */
	public Table<Integer, Integer, Double> readResult(String location) {
		Table<Integer, Integer, Double> dataTable = HashBasedTable.create();
		
		try {
			BufferedReader br = new BufferedReader(new FileReader(new File(location)));
			String line = "";
			String[] values = null;
			while((line = br.readLine()) != null) {
				values = line.split("\t");
				dataTable.put(Integer.parseInt(values[0]), Integer.parseInt(values[1]), Double.parseDouble(values[2]));
			}
			
			br.close();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return dataTable;
	}
	
	public void saveMatrix(SparseMatrix matrix, File file, int userCount, BiMap<Integer, String> inUserIds, BiMap<Integer, String> inItemIds) {
		try {
			if (!file.exists()) {
				file.createNewFile();
			}

			BufferedWriter bw = new BufferedWriter(new FileWriter(file));
			for (int u = 1; u <= userCount; u++) {
				int[] items = matrix.getRowRef(u).indexList();

				if (items != null) {
					for (int t = 0; t < items.length; t++) {
						int i = items[t];
						double value = matrix.getValue(u, i);

						bw.append(inUserIds.get(u) + "\t" + inItemIds.get(i) + "\t" + value + "\n");
					}
				}
			}
			bw.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 统计运行100次的MR评价预测结果并保�?
	 * @param mrFolder 
	 * @param folder
	 */
	public void statisticalResult(String mrFolder, int loop) {
		int pass = 0, failure = 0;
		double average_percent = 0;
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(new File(mrFolder + "/info.txt")));
			
			for(int i = 1; i <= loop; i++) {
				File file = new File(mrFolder + "/loop" + i + "/assertInfo.txt");
				try {
					BufferedReader br = new BufferedReader(new FileReader(file));
					String line = "";
					while((line = br.readLine()) != null) {
						if(line.contains("Assert:")) {
							if(line.split(": ")[1].equals("TRUE")){
								pass++;
								break;
							}
							else {
								failure++;
							}
						}
						if(line.contains("Percent:")) {
							average_percent += Double.parseDouble(line.split("Percent: ")[1]);
						}
					}
					br.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				
				File userfile = new File(mrFolder + "/loop" + i + "/train_test/userMapping.txt");
				ArrayList<String> userfileList = new ArrayList<String>();
				File itemfile = new File(mrFolder + "/loop" + i + "/train_test/itemMapping.txt");
				ArrayList<String> itemfileList = new ArrayList<String>();
				File mr_userfile = new File(mrFolder + "/loop" + i + "/mr_train_test/userMapping.txt");
				ArrayList<String> mr_userfileList = new ArrayList<String>();
				File mr_itemfile = new File(mrFolder + "/loop" + i + "/mr_train_test/itemMapping.txt");
				ArrayList<String>  mr_itemfileList = new ArrayList<String>();
				try {
					BufferedReader userfileBr = new BufferedReader(new FileReader(userfile));
					String line = "";
					while((line = userfileBr.readLine()) != null) {
						userfileList.add(line);
					}
					userfileBr.close();
					BufferedReader itemfileBr = new BufferedReader(new FileReader(itemfile));
					while((line = itemfileBr.readLine()) != null) {
						itemfileList.add(line);
					}
					itemfileBr.close();
					BufferedReader mr_userfileBr = new BufferedReader(new FileReader(mr_userfile));
					while((line = mr_userfileBr.readLine()) != null) {
						mr_userfileList.add(line);
					}
					mr_userfileBr.close();
					BufferedReader  mr_itemfileBr = new BufferedReader(new FileReader( mr_itemfile));
					while((line =  mr_itemfileBr.readLine()) != null) {
						 mr_itemfileList.add(line);
					}
					 mr_itemfileBr.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				int beforeUserSize = userfileList.size();
				userfileList.retainAll(mr_userfileList);
				int beforeItemSize = itemfileList.size();
				itemfileList.retainAll(mr_itemfileList);
				bw.append("loop"+ i +": userMappingNum=" + (beforeUserSize-userfileList.size()) + 
						", itemMappingNum=" +  (beforeItemSize-itemfileList.size()) + "\n");
			}
			
			bw.append(pass + ",");
			bw.append(failure + ",");
			if(failure == 0) {
				bw.append("0\n");
			}
			else {
				bw.append(average_percent/failure + "\n");
			}
			bw.close();
			
			System.out.println("\n\n\nPass:" + pass + "\n" + 
							   "Failure:" + failure);
			if(failure == 0) {
				System.out.println("Percent:0.0\n");
			}
			else {
				System.out.println("Percent:" + average_percent/failure + "\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	
}
