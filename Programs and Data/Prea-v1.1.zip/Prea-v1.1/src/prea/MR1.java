package prea;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Random;

import com.google.common.collect.BiMap;
import com.google.common.collect.Table;
import com.google.common.collect.Table.Cell;

import prea.data.structure.SparseMatrix;

/**
 * @author dazao1234
 * 随机选取两行并交换
 * 
 */
public class MR1 extends MR {
	
	public void execute(String folder, String mainFolder, SparseMatrix trainMatrix, SparseMatrix testMatrix,
			int userCount, BiMap<Integer, String> inUserIds, BiMap<Integer, String> inItemIds) {
		
		// 3.根据原始训练集与测试集信息生成MR对应的训练集与测试集信息
		// 进行 MR 操作
		ArrayList<String> ratings = new ArrayList<String>();
		try {
			File txt = new File(folder + "ratings.txt");
			BufferedReader txtBR = new BufferedReader(new FileReader(txt));
			String line = "";
			while((line = txtBR.readLine()) != null) {
				String[] split = line.split("\t");
				ratings.add(split[0] + "\t" + split[1] + "\t" + split[2]);
			}
			txtBR.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		int chooseIndex1, chooseIndex2;
		boolean flag3 = false, flag4 = false;
		do {
			chooseIndex1 = -1;
			chooseIndex2 = -1;
			flag3 = false;
			flag4 = false;
			
			boolean flag1 = false, flag2 = false;
			String chooseCol1, chooseCol2;
			do {
				flag1 = false;
				flag2 = false;
				chooseCol1 = null;
				chooseCol2 = null;
				
				Random random = new Random();
				chooseIndex1 = random.nextInt(ratings.size()/10);
				do {
					chooseIndex2 = random.nextInt(ratings.size()/10);
				} while (chooseIndex1 == chooseIndex2);
				if(chooseIndex1 > chooseIndex2) {
					int temp = chooseIndex1;
					chooseIndex1 = chooseIndex2;
					chooseIndex2 = temp;
				}
				
				String chooseRow1 = ratings.get(chooseIndex1).split("\t")[0];
				chooseCol1 = ratings.get(chooseIndex1).split("\t")[1];
				String chooseRow2 = ratings.get(chooseIndex2).split("\t")[0];
				chooseCol2 = ratings.get(chooseIndex2).split("\t")[1];
				
				for(int i = 0; i < chooseIndex2; i++) {
					if(i != chooseIndex1 && ratings.get(i).split("\t")[0].equals(chooseRow1)) {
						flag1 = true;
						break;
					}
					if(ratings.get(i).split("\t")[0].equals(chooseRow2)) {
						flag2 = true;
						break;
					}
				}
			}while(flag1 || flag2);
			
			for(int i = 0; i < chooseIndex1; i++) {
				if(ratings.get(i).split("\t")[1].equals(chooseCol1)) {
					flag3 = true;
				}
				if(ratings.get(i).split("\t")[1].equals(chooseCol2)) {
					flag4 = true;
				}
				if(flag3 && flag4) {
					break;
				}
			}
		}while(flag3 == false || flag4 == false);
		
		String chooseLine1 = ratings.get(chooseIndex1);
		String chooseLine2 = ratings.get(chooseIndex2);
		ratings.set(chooseIndex1, chooseLine2);
		ratings.set(chooseIndex2, chooseLine1);

		// 生成文件夹，保存经过MR操作的原始数据集集与测试�??
		File mr_train_testFolder = new File(mainFolder + "/mr_train_test");
		if (!mr_train_testFolder.exists()) {
			mr_train_testFolder.mkdirs();
		}
		saveData(mr_train_testFolder + "/mr_ratings.txt", ratings);
		saveMatrix(testMatrix, new File(mr_train_testFolder + "/mr_test.txt"),
				userCount, inUserIds, inItemIds);
		
		// 保存 chooseRow1, chooseRow2
		try {
			File file = new File(mainFolder + "/assertInfo.txt");
			if(!file.exists()) {
				file.createNewFile();
			}
			BufferedWriter txtBW = new BufferedWriter(new FileWriter(file));
			txtBW.append("chooseLine1:" + chooseIndex1 + "\nchooseLineInfo1:" + ratings.get(chooseIndex2) + "\n");
			txtBW.append("chooseLine2:" + chooseIndex2 + "\nchooseLineInfo2:" + ratings.get(chooseIndex1) + "\n");
			txtBW.close();                                                                             
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void assertion(String mainFolder, String mrFolder, int loop) {
		
		File mr_train_testFolder = new File(mainFolder + "/mr_train_test");
		if (!mr_train_testFolder.exists()) {
			mr_train_testFolder.mkdirs();
		}
		
		Table<Integer, Integer, Double> result_mr_dataTable = readResult(mainFolder + "/result_mr.txt");
		Table<Integer, Integer, Double> result_ori_dataTable = readResult(mainFolder + "/result_ori.txt");
		try{
			// 写入MR评价结果
			int count = 0;
			File file = new File(mainFolder + "/assertInfo.txt");
			BufferedWriter txtBW = new BufferedWriter(new FileWriter(file, true));
			txtBW.append("随机选取两行并交换位置，预测值应大致相同\n\n");
			txtBW.append("userID\titemID\tresult_ori\t\t\tresult_mr\t\t\tresult_difference\n");
			for(Cell<Integer, Integer, Double> cell : result_mr_dataTable.cellSet()) {
				if(result_ori_dataTable.get(cell.getRowKey(), cell.getColumnKey()) != null) {
					if(Math.abs(cell.getValue() - result_ori_dataTable.get(cell.getRowKey(), cell.getColumnKey())) > 0.1) {
							count++;
							txtBW.append(cell.getRowKey()+ "\t" +
										 cell.getColumnKey() + "\t" + 
										 result_ori_dataTable.get(cell.getRowKey(), cell.getColumnKey()) + "\t\t" + 
										 cell.getValue() + "\t\t" + 
										 Math.abs(cell.getValue() - result_ori_dataTable.get(cell.getRowKey(), cell.getColumnKey())) + "\n");
						}
				}
			}
			if(count == 0) {
				txtBW.append("\nAssert: TRUE\nPercent: 0.0");
			}
			else {
				txtBW.append("\nAssert: FALSE\nPercent: " + count/(double)result_mr_dataTable.cellSet().size());
			}
			txtBW.close();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		if(loop == 100) {
			statisticalResult(mrFolder, loop);
		}
	}

}
