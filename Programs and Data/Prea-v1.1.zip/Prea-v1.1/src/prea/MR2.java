package prea;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Random;

import com.google.common.collect.BiMap;
import com.google.common.collect.Table;
import com.google.common.collect.Table.Cell;

import prea.data.structure.SparseMatrix;

/**
 * @author dazao1234
 * 
 * 操作: 根据 y = θ * x 更新训练矩阵和测试矩阵评值，θ策略为：[1, 10]，步长为1
 * 评价策略: 预测值应符合 y = θ * x
 * 
 */
public class MR2 extends MR {

	/**
	 * 根据MR生成训练集与测试集信
	 * @param loop
	 */
	public void execute(String folder, String mainFolder, SparseMatrix trainMatrix, SparseMatrix testMatrix,
			int userCount, BiMap<Integer, String> inUserIds, BiMap<Integer, String> inItemIds) {
		
		// 3.根据原始训练集与测试集信息生成MR对应的训练集与测试集信息
		// 进行 MR 操作
		Random random = new Random();
		int theta = random.nextInt(10) + 1; //[1, 10]，步长为1
		// 生成经过变换的原始数据集
		ArrayList<String> mr_ratings = new ArrayList<String>();
		try {
			File txt = new File(folder + "ratings.txt");
			BufferedReader txtBR = new BufferedReader(new FileReader(txt));
			String line = "";
			while((line = txtBR.readLine()) != null) {
				String[] split = line.split("\t");
				double parseDouble = Double.parseDouble(split[2]) * theta;
				mr_ratings.add(split[0] + "\t" + split[1] + "\t" + parseDouble);
			}
			txtBR.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		// 生成训练数据
		SparseMatrix myTestMatrix = new SparseMatrix(testMatrix);
		for (int u = 1; u <= userCount; u++) {
			int[] items = myTestMatrix.getRowRef(u).indexList();

			if (items != null) {
				for (int t = 0; t < items.length; t++) {
					int i = items[t];
					double value = myTestMatrix.getValue(u, i)  * theta;
					myTestMatrix.setValue(u, i, value);
				}
			}
		}
		
		// 生成文件夹，保存经过MR操作的原始数据集与测试数据集
		File mr_train_testFolder = new File(mainFolder + "/mr_train_test");
		if (!mr_train_testFolder.exists()) {
			mr_train_testFolder.mkdirs();
		}
		saveData(mr_train_testFolder + "/mr_ratings.txt", mr_ratings);
		saveMatrix(myTestMatrix, new File(mr_train_testFolder + "/mr_test.txt"),
				userCount, inUserIds, inItemIds);
		
		// 保存 theta
		try {
			File file = new File(mainFolder + "/assertInfo.txt");
			if(!file.exists()) {
				file.createNewFile();
			}
			BufferedWriter txtBW = new BufferedWriter(new FileWriter(file));
			txtBW.append("theta:" + theta + "\n");
			
			txtBW.close();                                                                             
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 根据MR的评价策略进行评价操作，保存MR评价结果
	 * @param loop
	 */
	public void assertion(String mainFolder, String mrFolder, int loop) {
		
		File mr_train_testFolder = new File(mainFolder + "/mr_train_test");
		if (!mr_train_testFolder.exists()) {
			mr_train_testFolder.mkdirs();
		}
		
		Table<Integer, Integer, Double> result_mr_dataTable = readResult(mainFolder + "/result_mr.txt");
		Table<Integer, Integer, Double> result_ori_dataTable = readResult(mainFolder + "/result_ori.txt");
		
		try{
			// 读取 theta
			File file = new File(mainFolder + "/assertInfo.txt");
			BufferedReader txtBR = new BufferedReader(new FileReader(file));
			String line = "";
			int theta = 0;
			while((line = txtBR.readLine()) != null) {
				if(line.contains("theta:")) {
					theta = Integer.parseInt(line.split(":")[1]);
				}
			}
			txtBR.close();
			
			// 写入MR评价结果
			int count = 0;
			BufferedWriter txtBW = new BufferedWriter(new FileWriter(file, true));
			txtBW.append("线�?�缩放theta倍，预测值应大致为x * theta倍\n\n");
			txtBW.append("userID\titemID\tresult_ori\t\t\tresult_mr\t\t\tresult_difference\n");
			for(Cell<Integer, Integer, Double> cell : result_mr_dataTable.cellSet()) {
				if(result_ori_dataTable.get(cell.getRowKey(), cell.getColumnKey()) != null) {
					if(Math.abs(cell.getValue() - result_ori_dataTable.get(cell.getRowKey(), cell.getColumnKey()) * theta) > 0.1) {
							count++;
							txtBW.append(cell.getRowKey()+ "\t" +
										 cell.getColumnKey() + "\t" + 
										 result_ori_dataTable.get(cell.getRowKey(), cell.getColumnKey()) + "\t\t" + 
										 cell.getValue() + "\t\t" + 
										 Math.abs(cell.getValue() - result_ori_dataTable.get(cell.getRowKey(), cell.getColumnKey()) * theta) + "\n");
						}
				}
				
			}
			if(count == 0) {
				txtBW.append("\nAssert: TRUE\nPercent: 0.0");
			}
			else {
				txtBW.append("\nAssert: FALSE\nPercent: " + count/(double)result_mr_dataTable.cellSet().size());
			}
			txtBW.close();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		if(loop == 100) {
			statisticalResult(mrFolder, loop);
		}
	}

}
