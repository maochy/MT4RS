package prea;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;

import com.google.common.collect.BiMap;
import com.google.common.collect.Table;
import com.google.common.collect.Table.Cell;

import prea.data.structure.SparseMatrix;

/**
 * @author dazao1234
 * 
 * 操作: 根据 y = -1 * x + 6 更新训练矩阵和测试矩阵评分取值
 * 评价策略: 预测值应符合  y = -1 * x + 6 
 * 
 */
public class MR5 extends MR {

	/**
	 * 根据MR生成训练集与测试集
	 * @param loop
	 */
	public void execute(String folder, String mainFolder, SparseMatrix trainMatrix, SparseMatrix testMatrix,
			int userCount, BiMap<Integer, String> inUserIds, BiMap<Integer, String> inItemIds) {
		
		// 3.根据原始训练集与测试集信息生成MR对应的训练集与测试集信息
		// 生成经过变换的原始数据集
		ArrayList<String> mr_ratings = new ArrayList<String>();
		try {
			File txt = new File(folder + "ratings.txt");
			BufferedReader txtBR = new BufferedReader(new FileReader(txt));
			String line = "";
			while((line = txtBR.readLine()) != null) {
				String[] split = line.split("\t");
				double parseDouble = 6 - Double.parseDouble(split[2]);
				mr_ratings.add(split[0] + "\t" + split[1] + "\t" + parseDouble);
			}
			txtBR.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		// 生成训练
		SparseMatrix myTestMatrix = new SparseMatrix(testMatrix);
		for (int u = 1; u <= userCount; u++) {
			int[] items = myTestMatrix.getRowRef(u).indexList();

			if (items != null) {
				for (int t = 0; t < items.length; t++) {
					int i = items[t];
					double value = 6 - myTestMatrix.getValue(u, i);
					myTestMatrix.setValue(u, i, value);
				}
			}
		}
		
		// 生成文件夹，保存经过MR操作的原始数据集集与测试
		File mr_train_testFolder = new File(mainFolder + "/mr_train_test");
		if (!mr_train_testFolder.exists()) {
			mr_train_testFolder.mkdirs();
		}
		saveData(mr_train_testFolder + "/mr_ratings.txt", mr_ratings);
		saveMatrix(myTestMatrix, new File(mr_train_testFolder + "/mr_test.txt"),
				userCount, inUserIds, inItemIds);
	}

	/**
	 * 根据MR的评价策略进行评价操作，保存MR评价结果
	 * @param loop
	 */
	public void assertion(String mainFolder, String mrFolder, int loop) {
		
		File mr_train_testFolder = new File(mainFolder + "/mr_train_test");
		if (!mr_train_testFolder.exists()) {
			mr_train_testFolder.mkdirs();
		}
		
		Table<Integer, Integer, Double> result_mr_dataTable = readResult(mainFolder + "/result_mr.txt");
		Table<Integer, Integer, Double> result_ori_dataTable = readResult(mainFolder + "/result_ori.txt");
		
		try{
			// 写入MR评价结果
			File file = new File(mainFolder + "/assertInfo.txt");
			int count = 0;
			BufferedWriter txtBW = new BufferedWriter(new FileWriter(file, true));
			txtBW.append("使用�??6 - 原始评分值）更新整个数据集\n\n");
			txtBW.append("userID\titemID\tresult_ori\t\t\tresult_mr\t\t\tresult_difference\n");
			for(Cell<Integer, Integer, Double> cell : result_mr_dataTable.cellSet()) {
				if(result_ori_dataTable.get(cell.getRowKey(), cell.getColumnKey()) != null) {
					if(Math.abs(6 - cell.getValue() - result_ori_dataTable.get(cell.getRowKey(), cell.getColumnKey())) > 0.1) {
							count++;
							txtBW.append(cell.getRowKey()+ "\t" +
										 cell.getColumnKey() + "\t" + 
										 result_ori_dataTable.get(cell.getRowKey(), cell.getColumnKey()) + "\t\t" + 
										 cell.getValue() + "\t\t" + 
										 Math.abs(6 - cell.getValue() - result_ori_dataTable.get(cell.getRowKey(), cell.getColumnKey())) + "\n");
					}
				}
				
			}
			if(count == 0) {
				txtBW.append("\nAssert: TRUE\nPercent: 0.0");
			}
			else {
				txtBW.append("\nAssert: FALSE\nPercent: " + count/(double)result_mr_dataTable.cellSet().size());
			}
			txtBW.close();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		if(loop == 100) {
			statisticalResult(mrFolder, loop);
		}
	}

}
