package prea;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Random;

import com.google.common.collect.BiMap;
import com.google.common.collect.Table;

import prea.data.structure.SparseMatrix;

/**
 * @author dazao1234
 * 
 * 操作: 随机挑选训练集中一行，使用该行数据复制新增一个相同的用户
 * 评价策略: 该用户与新增用户的预测值应大致相同
 * 
 */
public class MR6 extends MR {
	
	/**
	 * 根据MR生成训练集与测试集
	 * @param loop
	 */
	public void execute(String folder, String mainFolder, SparseMatrix trainMatrix, SparseMatrix testMatrix,
			int userCount, BiMap<Integer, String> inUserIds, BiMap<Integer, String> inItemIds) {
		
		// 从训练集中挑选合适的userId
		int chooseRowIndex = -1;
		int preferenceColumns = 0, trainColumns = 0, testColumns = 0;
		Random random = new Random();
		do {
			chooseRowIndex = random.nextInt(inUserIds.size() + 1);
			if(trainMatrix.getRow(chooseRowIndex).indexList() != null) {
				trainColumns = trainMatrix.getRow(chooseRowIndex).indexList().length;
			}
			else {
				trainColumns = 0;
			}
			if(testMatrix.getRow(chooseRowIndex).indexList() != null) {
				testColumns = testMatrix.getRow(chooseRowIndex).indexList().length;
			}
			else {
				testColumns = 0;
			}
			preferenceColumns = trainColumns + testColumns;
		}while(testColumns <= 0 || trainColumns <= 0);
		
		// 获取当前最大的用户id，用于构造新用户id
		int maxId = -1;
		for(String idStr : inUserIds.values()) {
			if(maxId < Integer.parseInt(idStr)) {
				maxId = Integer.parseInt(idStr);
			}
		}
		
		// 生成经过变换的原始数据集
		ArrayList<String> mr_ratings = new ArrayList<String>();
		try {
			File txt = new File(folder + "ratings.txt");
			BufferedReader txtBR = new BufferedReader(new FileReader(txt));
			String line = "";
			while((line = txtBR.readLine()) != null) {
				String[] split = line.split("\t");
				mr_ratings.add(split[0] + "\t" + split[1] + "\t" + split[2]);
			}
			txtBR.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		for(int itemId : trainMatrix.getRow(chooseRowIndex).indexList()) {
			mr_ratings.add((maxId+1) + "\t" + 
					inItemIds.get(itemId) + "\t" + 
					trainMatrix.getValue(chooseRowIndex, itemId));
		}
		for(int itemId : testMatrix.getRow(chooseRowIndex).indexList()) {
			mr_ratings.add((maxId+1) + "\t" + 
					inItemIds.get(itemId) + "\t" + 
					testMatrix.getValue(chooseRowIndex, itemId));
		}
		
		// 生成文件
		File mr_train_testFolder = new File(mainFolder + "/mr_train_test");
		if (!mr_train_testFolder.exists()) {
			mr_train_testFolder.mkdirs();
		}
		saveData(mr_train_testFolder + "/mr_ratings.txt", mr_ratings);
		saveMatrix(testMatrix, new File(mr_train_testFolder + "/mr_test.txt"),
				userCount, inUserIds, inItemIds);
		
		// 根据选出的行构造新用户，分别将数据写入测试集
		try {
			BufferedWriter mr_testBW = new BufferedWriter(new FileWriter(new File(mr_train_testFolder + "/mr_test.txt"), true));
			for(int testItemId : testMatrix.getRow(chooseRowIndex).indexList()) {
				mr_testBW.append((maxId+1) + "\t" + 
						inItemIds.get(testItemId) + "\t" + 
						testMatrix.getValue(chooseRowIndex, testItemId) + "\n");
			}
			mr_testBW.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// 保存信息
		try {
			File file = new File(mainFolder + "/assertInfo.txt");
			if(!file.exists()) {
				file.createNewFile();
			}
			BufferedWriter txtBW = new BufferedWriter(new FileWriter(file));
			txtBW.append("chooseRowIndex:" + inUserIds.get(chooseRowIndex) + "\n");
			txtBW.append("newRowIndex:" + (maxId + 1) + "\n");
			txtBW.append("preferenceColumns:" + preferenceColumns + "\n" + "trainColumns:" + trainColumns + "\n" +
						 "testColumns:" + (preferenceColumns - trainColumns) + "\n");
			txtBW.append("trainColumnIDs:");
			for(int col : trainMatrix.getRow(chooseRowIndex).indexList()) {
				txtBW.append(inItemIds.get(col) + ",");
			}
			txtBW.append("\n");
			txtBW.append("testColumnIDs:");
			for(int col : testMatrix.getRow(chooseRowIndex).indexList()) {
				txtBW.append(inItemIds.get(col) + ",");
			}
			txtBW.append("\n");
			txtBW.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}

	/**
	 * 根据MR的评价策略进行评价操作，判断是否通过MR
	 * @param loop
	 */
	public void assertion(String mainFolder, String mrFolder, int loop) {
		// 生成文件
		File mr_train_testFolder = new File(mainFolder + "/mr_train_test");
		if (!mr_train_testFolder.exists()) {
			mr_train_testFolder.mkdirs();
		}
		
		Table<Integer, Integer, Double> result_mr_dataTable = readResult(mainFolder + "/result_mr.txt");
		
		try{
			int chooseRowIndex = -1, newRowIndex = -1, testColumns = 0;
			ArrayList<Integer> testColumnIDs = new ArrayList<Integer>();
			
			File file = new File(mainFolder + "/assertInfo.txt");
			BufferedReader txtBR = new BufferedReader(new FileReader(file));
			
			String line = "";
			while((line = txtBR.readLine()) != null) {
				if(line.contains("chooseRowIndex:")) {
					chooseRowIndex = Integer.parseInt(line.split(":")[1]);
				}
				if(line.contains("newRowIndex:")) {
					newRowIndex = Integer.parseInt(line.split(":")[1]);
				}
				if(line.contains("testColumns:")) {
					testColumns = Integer.parseInt(line.split(":")[1]);
				}
				if(line.contains("testColumnIDs:")) {
					String idsStr = line.split(":")[1];
					String[] ids = idsStr.split(",");
					for(String id : ids) {
						testColumnIDs.add(Integer.parseInt(id));
					}
				}
			}
			txtBR.close();
			
			int count = 0;
			BufferedWriter txtBW = new BufferedWriter(new FileWriter(file, true));
			txtBW.append("\n增加�?个完全相同的用户，这两个用户的预测�?�应该大致相同\n\n");
			txtBW.append("userID\tnewUserID\titemID\tresult_ori\t\t\tresult_new\t\t\tori-new_result\n");
			for(int colId : testColumnIDs) {
				if(result_mr_dataTable.get(chooseRowIndex, colId) != null && result_mr_dataTable.get(newRowIndex, colId) != null){
					if(Math.abs(result_mr_dataTable.get(chooseRowIndex, colId) - result_mr_dataTable.get(newRowIndex, colId)) > 0.1) {
							count++;
							txtBW.append(chooseRowIndex+ "\t" + 
										 newRowIndex+ "\t\t" + 
										 colId + "\t" + 
										 result_mr_dataTable.get(chooseRowIndex, colId) + "\t\t" + 
										 result_mr_dataTable.get(newRowIndex, colId) + "\t\t\t" + 
										 Math.abs(result_mr_dataTable.get(chooseRowIndex, colId) - result_mr_dataTable.get(newRowIndex, colId)) + "\n");
					}
				}
			}
			
			if(count == 0) {
				txtBW.append("\nAssert: TRUE\nPercent: 0.0");
			}
			else {
				txtBW.append("\nAssert: FALSE\nPercent: " + count/(double)testColumns);
			}
			txtBW.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		if(loop == 100) {
			statisticalResult(mrFolder, loop);
		}
	}
	
}
