package prea;

import prea.data.splitter.DataSplitManager;
import prea.main.Prea;

public class Main {

	public static void main(String[] args) {
		
		//被测试程序
		String algorithmCode = "avg";
//		String algorithmCode = "const";
//		String algorithmCode = "itemavg";
//		String algorithmCode = "itembased";
//		String algorithmCode = "nmf";
//		String algorithmCode = "pmf";
//		String algorithmCode = "random";
//		String algorithmCode = "regsvd";
//		String algorithmCode = "useravg";
//		String algorithmCode = "userbased";
		
		
		// 数据集划分方式
		int splitModel = DataSplitManager.SIMPLE_SPLIT; // 随机划分
//		int splitModel = DataSplitManager.PREDEFINED_SPLIT; // 固定划分 
		
		// 使用某一MR对被测程序进行测试
		String mr_id = "MR1";
		MR mr = new MR1();
//		String mr_id = "MR2";
//		MR mr = new MR2();
//		String mr_id = "MR3";
//		MR mr = new MR3();
//		String mr_id = "MR4";
//		MR mr = new MR4();
//		String mr_id = "MR5";
//		MR mr = new MR5();
//		String mr_id = "MR6";
//		MR mr = new MR6();
		
		
		// 测试入口
		exe(algorithmCode, splitModel, mr_id, mr);
	}
	
	public static void exe(String algorithmCode, int splitterModel, String mrID, MR mr){
		// 测试重复100次
		for(int i = 1; i <= 100; i++) {
			Prea prea = new Prea(algorithmCode, splitterModel, mrID, mr);
			prea.runJob(i);
		}
	}
	
}
