package prea.data.splitter;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import com.google.common.collect.BiMap;

import prea.data.structure.SparseMatrix;

/**
 * When a predefined split file is available,
 * this class helps to split train/test set as defined in the file.
 * This can be used for verifying implementation of new CF algorithm. 
 * 
 * @author Joonseok Lee
 * @since 2012. 4. 20
 * @version 1.1
 */
public class PredefinedSplit extends DataSplitManager {
	/*========================================
	 * Constructors
	 *========================================*/
	/** Construct an instance for splitter with predefined split file.*/
	public PredefinedSplit(SparseMatrix originalMatrix, 
			BiMap<String, Integer> userIds, BiMap<String, Integer> itemIds, String splitFileName,
			int max, int min) {
		super(originalMatrix, max, min);
		readSplitData(userIds, itemIds, splitFileName);
		calculateAverage((maxValue + minValue) / 2);
	}
	
	/**
	 * Split the rating matrix into train and test set, by given split data file.
	 * @param itemIds 
	 * @param userIds 
	 * 
	 * @param fileName the name of split data file. 
	 * 
	 **/
	private void readSplitData(BiMap<String, Integer> userIds, BiMap<String, Integer> itemIds, String fileName) {
		recoverTestItems();
		
		try {
			BufferedReader br = new BufferedReader(new FileReader(new File(fileName)));
			String line;
			// Read data:
			while((line = br.readLine()) != null) {
				String[] data = line.trim().split("[ \t,]+");
	            int userId = userIds.get(data[0]);
	            int itemId = itemIds.get(data[1]);
				double rate = Double.parseDouble(data[2]);
				
				rateMatrix.setValue(userId, itemId, 0.0);
				testMatrix.setValue(userId, itemId, rate);
			}
			br.close();
		}
		catch (IOException ioe) {
			System.out.println ("No such file: " + ioe);
			System.exit(0);
		}
	}
}
