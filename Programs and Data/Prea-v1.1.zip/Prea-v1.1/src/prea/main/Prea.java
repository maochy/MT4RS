package prea.main;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Map.Entry;

import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;

import prea.data.splitter.DataSplitManager;
import prea.data.splitter.PredefinedSplit;
import prea.data.splitter.SimpleSplit;
import prea.data.structure.SparseMatrix;
import prea.data.structure.SparseVector;
import prea.recommender.Recommender;
import prea.recommender.baseline.Average;
import prea.recommender.baseline.Constant;
import prea.recommender.baseline.ItemAverage;
import prea.recommender.baseline.Random;
import prea.recommender.baseline.UserAverage;
import prea.recommender.matrix.NMF;
import prea.recommender.matrix.PMF;
import prea.recommender.matrix.RegularizedSVD;
import prea.recommender.memory.ItemBased;
import prea.recommender.memory.MemoryBasedRecommender;
import prea.recommender.memory.UserBased;
import prea.MR;
import prea.util.EvaluationMetrics;

/**
 * The main class of this toolkit. It includes loading the dataset, splitting
 * train/test set, and interface to evaluation for each algorithms.
 * 
 * @author Joonseok Lee
 * @since 2012. 4. 20
 * @version 1.1
 */
public class Prea {
	/*
	 * ======================================== Parameters
	 * ========================================
	 */
	private String algorithmCode;
	private int splitMode;
	private String mrID;
	private MR mr;

	private String folder = "data\\movielens\\100k\\";

	/*
	 * ======================================== Common Variables
	 * ========================================
	 */
	/** Rating matrix for each user (row) and item (column) */
	private SparseMatrix trainMatrix;
	/**
	 * Rating matrix for test items. Not allowed to refer during training and
	 * validation phase.
	 */
	private SparseMatrix testMatrix;
	/** Average of ratings for each user. */
	private SparseVector userRateAverage;
	/** Average of ratings for each item. */
	private SparseVector itemRateAverage;
	/** The number of users. */
	private int userCount;
	/** The number of items. */
	private int itemCount;
	/** Maximum value of rating, existing in the dataset. */
	private double maxValue;
	/** Minimum value of rating, existing in the dataset. */
	private double minValue;

	/** user/item {raw id, inner id} map */
	private BiMap<String, Integer> userIds, itemIds;

	/** user/item {raw id, inner id} map */
	private BiMap<Integer, String> inUserIds, inItemIds;

	public Prea(String algorithmCode, int splitMode, String mrID, MR mr) {
		this.algorithmCode = algorithmCode;
		this.splitMode = splitMode;
		this.mrID = mrID;
		this.mr = mr;
	}

	/**
	 * Test examples for every algorithm. Also includes parsing the given
	 * parameters.
	 */
	public void runJob(int i) {
		// Train/test data split:
		switch (splitMode) {
		case DataSplitManager.SIMPLE_SPLIT:
			// Read input file:
			readRateTxt(folder + "ratings.txt");

			double testRatio = 0.2;
			SimpleSplit sSplit = new SimpleSplit(trainMatrix, testRatio, (int)maxValue, (int)minValue);
			testMatrix = sSplit.getTestMatrix();
			userRateAverage = sSplit.getUserRateAverage();
			itemRateAverage = sSplit.getItemRateAverage();

			runIndividual(i);
			break;
		case DataSplitManager.PREDEFINED_SPLIT:
			// Read input file:��
			String rateMatrixFile = folder + algorithmCode + "\\" + this.mrID + "\\loop" + i
					+ "\\mr_train_test\\mr_ratings.txt";
			readRateTxt(rateMatrixFile);
			String testMatrixFile = folder + algorithmCode + "\\" + this.mrID + "\\loop" + i
					+ "\\mr_train_test\\mr_test.txt";
			
			PredefinedSplit pSplit = new PredefinedSplit(trainMatrix, userIds, itemIds, testMatrixFile, 
					(int)maxValue, (int)minValue);
			testMatrix = pSplit.getTestMatrix();
			userRateAverage = pSplit.getUserRateAverage();
			itemRateAverage = pSplit.getItemRateAverage();

			runIndividual(i);
			break;
		}
	}

	private void readRateTxt(String fileName) {
		File file = new File(fileName);
		userIds = HashBiMap.create();
		itemIds = HashBiMap.create();
		try {
			BufferedReader br = new BufferedReader(new FileReader(file));
			String line;

			while ((line = br.readLine()) != null) {
				String[] data = line.trim().split("[ \t,]+");
				String user = data[0];
				String item = data[1];
				double rate = Double.parseDouble(data[2]);

				int row = userIds.containsKey(user) ? userIds.get(user) : userIds.size() + 1;
				userIds.put(user, row);

				int col = itemIds.containsKey(item) ? itemIds.get(item) : itemIds.size() + 1;
				itemIds.put(item, col);

				if (rate > maxValue) {
					maxValue = rate;
				} else if (rate < minValue) {
					minValue = rate;
				}
			}
			br.close();
		} catch (IOException ioe) {
			System.out.println("No such file: " + ioe);
			System.exit(0);
		}

		userCount = userIds.size();
		itemCount = itemIds.size();

		trainMatrix = new SparseMatrix(userCount + 1, itemCount + 1);

		try {
			BufferedReader br = new BufferedReader(new FileReader(file));
			String line;
			// Read data:
			while ((line = br.readLine()) != null) {
				String[] data = line.trim().split("[ \t,]+");
				int userId = userIds.get(data[0]);
				int itemId = itemIds.get(data[1]);
				double rate = Double.parseDouble(data[2]);

				trainMatrix.setValue(userId, itemId, rate);
			}
			br.close();
		} catch (IOException ioe) {
			System.out.println("No such file: " + ioe);
			System.exit(0);
		}
	}
	

	private void runIndividual(int loop) {
		inUserIds = userIds.inverse();
		inItemIds = itemIds.inverse();

		if (algorithmCode.toLowerCase().equals("const")) {
			Constant constant = new Constant(userCount, itemCount, maxValue, minValue, 3.0);
			testRecommender(constant, loop);
		} else if (algorithmCode.toLowerCase().equals("avg")) {
			Average average = new Average(userCount, itemCount, maxValue, minValue);
			testRecommender(average, loop);
		} else if (algorithmCode.toLowerCase().equals("useravg")) {
			UserAverage userAverage = new UserAverage(userCount, itemCount, maxValue, minValue, userRateAverage);
			testRecommender(userAverage, loop);
		} else if (algorithmCode.toLowerCase().equals("itemavg")) {
			ItemAverage itemAverage = new ItemAverage(userCount, itemCount, maxValue, minValue, itemRateAverage);
			testRecommender(itemAverage, loop);
		} else if (algorithmCode.toLowerCase().equals("random")) {
			Random random = new Random(userCount, itemCount, maxValue, minValue);
			testRecommender(random, loop);
		} else if (algorithmCode.toLowerCase().equals("regsvd")) {
			RegularizedSVD regsvd = new RegularizedSVD(userCount, itemCount, maxValue, minValue, 10, 0.005, 0.1, 0, 200, false);
			testRecommender(regsvd, loop);
		} else if (algorithmCode.toLowerCase().equals("nmf")) {
			NMF nmf = new NMF(userCount, itemCount, maxValue, minValue, 4, 0, 0.001, 0, 200, 0.005, false);
			testRecommender(nmf, loop);
		} else if (algorithmCode.toLowerCase().equals("pmf")) {
			PMF pmf = new PMF(userCount, itemCount, maxValue, minValue, 10, 50, 0.4, 0.8, 200, false);
			testRecommender(pmf, loop);
		} else if (algorithmCode.toLowerCase().equals("userbased")) {
			UserBased userBsd = new UserBased(userCount, itemCount, (int)maxValue, (int)minValue, 50, MemoryBasedRecommender.PEARSON_CORR, false, 0.0, userRateAverage, false, "");
			testRecommender(userBsd, loop);
		} else if (algorithmCode.toLowerCase().equals("itembased")) {
			ItemBased itemBsd = new ItemBased(userCount, itemCount, (int)maxValue, (int)minValue, 50, MemoryBasedRecommender.PEARSON_CORR, false, 0.0, itemRateAverage, false, "");
			testRecommender(itemBsd, loop);
		}
		
	}

	private void testRecommender(Recommender r, int loop) {
		r.buildModel(trainMatrix);
		EvaluationMetrics result = r.evaluate(testMatrix);
		String mainFolder = folder + algorithmCode + "\\" + this.mrID + "\\loop" + loop;
		String mrFolder = folder + algorithmCode + "\\" + this.mrID;

		if (splitMode == DataSplitManager.SIMPLE_SPLIT) {
			File mainFolderFile = new File(mainFolder);
			if (!mainFolderFile.exists()) {
				mainFolderFile.mkdirs();
			}

			saveMatrix(result.getPrediction(), new File(mainFolder + "\\result_ori.txt"));

			saveEva(result.getMAE(), result.getRMSE(),
					new File(mainFolder + "\\result_eva_ori.txt"));

			File train_testFile = new File(mainFolder + "\\train_test");
			if (!train_testFile.exists()) {
				train_testFile.mkdirs();
			}
			saveInIds(inUserIds, new File(train_testFile + "\\userMapping.txt"));
			saveInIds(inItemIds, new File(train_testFile + "\\itemMapping.txt"));

			File mr_train_testFile = new File(mainFolder + "\\mr_train_test");
			if (!mr_train_testFile.exists()) {
				mr_train_testFile.mkdirs();
			}
			this.mr.execute(folder, mainFolder, trainMatrix ,result.getTestMatrix(), userCount, inUserIds, inItemIds);
		}

		if (splitMode == DataSplitManager.PREDEFINED_SPLIT) {
			File mainFolderFile = new File(mainFolder);
			if (!mainFolderFile.exists()) {
				mainFolderFile.mkdirs();
			}

			saveMatrix(result.getPrediction(), new File(mainFolder + "\\result_mr.txt"));

			saveEva(result.getMAE(), result.getRMSE(),
					new File(mainFolder + "\\result_eva_mr.txt"));

			File train_testFile = new File(mainFolder + "\\mr_train_test");
			if (!train_testFile.exists()) {
				train_testFile.mkdirs();
			}
			saveInIds(inUserIds, new File(train_testFile + "\\userMapping.txt"));
			saveInIds(inItemIds, new File(train_testFile + "\\itemMapping.txt"));
			
			this.mr.assertion(mainFolder, mrFolder, loop);
		}

	}

	
	private void saveInIds(BiMap<Integer, String> inIds, File file) {
		try {
			if (!file.exists()) {
				file.createNewFile();
			}
			BufferedWriter bw = new BufferedWriter(new FileWriter(file));
			for (Entry<Integer, String> entry : inIds.entrySet()) {
				bw.append(entry.getKey() + "b" + entry.getValue() + "\n");
			}
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	private void saveEva(double mae, double rmse, File file) {
		try {
			if (!file.exists()) {
				file.createNewFile();
			}

			BufferedWriter bw = new BufferedWriter(new FileWriter(file));
			bw.append("MAE: " + mae + "\n");
//			bw.append("MSE: " + mse + "\n");
			bw.append("RMSE: " + rmse + "\n");
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	
	private void saveMatrix(SparseMatrix matrix, File file) {
		try {
			if (!file.exists()) {
				file.createNewFile();
			}

			BufferedWriter bw = new BufferedWriter(new FileWriter(file));
			for (int u = 1; u <= userCount; u++) {
				int[] items = matrix.getRowRef(u).indexList();

				if (items != null) {
					for (int t = 0; t < items.length; t++) {
						int i = items[t];
						double value = matrix.getValue(u, i);

						bw.append(inUserIds.get(u) + "\t" + inItemIds.get(i) + "\t" + value + "\n");
					}
				}
			}
			bw.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}