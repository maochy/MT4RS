package mr;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Map.Entry;

import com.google.common.collect.BiMap;
import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Table;

import net.librec.conf.Configuration;
import net.librec.data.DataModel;
import net.librec.data.model.TextDataModel;
import net.librec.math.structure.MatrixEntry;
import net.librec.math.structure.SparseMatrix;

public abstract class MR {
	
	protected DataModel dataModel;

	protected Configuration conf;
	
	protected String mainFolderLoopStr;
	protected String mainFolderStr;
	protected BiMap<Integer, String> userMappingData;
	protected BiMap<Integer, String> itemMappingData;
	protected SparseMatrix preferenceMatrix;
	protected SparseMatrix trainMatrix;
	protected SparseMatrix testMatrix;
	
	public void setConfAndDataModel(Configuration conf, DataModel dataModel) {
		this.conf = conf;
		this.dataModel = dataModel;
	}
	
	public void setMainFolderStr(int loop, String className) {
		String resultDir = conf.get("dfs.result.dir");
		String recommenderClass = conf.get("rec.recommender.class");
		mainFolderLoopStr = resultDir + "/" + recommenderClass + "/" + className + "/" + "loop" + loop;
		mainFolderStr = resultDir + "/" + recommenderClass + "/" + className;
	}
	
	/**
	 * 根据MR生成训练集与测试集信息
	 * @param loop
	 */
	public abstract void execute(int loop);
	
	/**
	 * 根据MR的评价策略进行评价操作，保存MR评价结果
	 * @param loop
	 */
	public abstract void assertion(int loop);
	
	/**
	 * 获取并保存原始训练集与测试集
	 * @param loop
	 */
	public void beforeExecute(int loop, String className) {
		
		setMainFolderStr(loop, className);
		
		// 读取信息
		userMappingData = ((TextDataModel) dataModel).getUserMappingData().inverse();
		itemMappingData = ((TextDataModel) dataModel).getItemMappingData().inverse();
		preferenceMatrix = ((TextDataModel) dataModel).getMyPreferenceMatrix();
		trainMatrix = ((TextDataModel) dataModel).getMyTrainMatrix();
		testMatrix = ((TextDataModel) dataModel).getMyTestMatrix();
		
		// 生成文件夹
		File mainFolder = new File(mainFolderLoopStr);
		if (!mainFolder.exists()) {
			mainFolder.mkdirs();
		}
	}
	
	/**
	 * 保存矩阵数据到txt文本中
	 * @param location
	 * @param matrix
	 * @param userMappingData
	 * @param itemMappingData
	 * @return
	 */
	protected boolean saveData(String location, SparseMatrix matrix, BiMap<Integer, String> userMappingData, BiMap<Integer, String> itemMappingData) {
		try {
			File txt = new File(location);
			if(!txt.exists()) {
				txt.createNewFile();
			}
			BufferedWriter txtBW = new BufferedWriter(new FileWriter(txt));
			// 不为空则是原始矩阵
			if(userMappingData == null && itemMappingData == null) {
				for (MatrixEntry matrixEntry : matrix) {
					txtBW.append(matrixEntry.row() + "\t" + matrixEntry.column() + "\t" + matrixEntry.get() + "\n");
				}
			}
			else {
				for (MatrixEntry matrixEntry : matrix) {
					txtBW.append(userMappingData.get(matrixEntry.row()) + "\t" + itemMappingData.get(matrixEntry.column()) + "\t" + matrixEntry.get() + "\n");
				}
			}
			
			txtBW.close();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	/**
	 *  保存数据到txt文本中
	 * @param location
	 * @param mr_ratings
	 * @return
	 */
	protected boolean saveData(String location, ArrayList<String> mr_ratings) {
		try {
			File txt = new File(location);
			if(!txt.exists()) {
				txt.createNewFile();
			}
			BufferedWriter txtBW = new BufferedWriter(new FileWriter(txt));
			// 不为空则是原始矩阵
			for(String str : mr_ratings) {
				txtBW.append(str + "\n");
			}
			txtBW.close();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	/**
	 * 保存mapping数据到txt文本中
	 * @param location
	 * @param mappingData
	 * @return
	 */
	protected boolean saveMappingData(String location, BiMap<Integer, String> mappingData) {
		try {
			File txt = new File(location);
			if(!txt.exists()) {
				txt.createNewFile();
			}
			BufferedWriter txtBW = new BufferedWriter(new FileWriter(txt));
			// 不为空则是原始矩阵
			for(Entry<Integer, String> entry : mappingData.entrySet()) {
				txtBW.append(entry.getKey() + "b" + entry.getValue() + "\n");
			}
			txtBW.close();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	
	/**
	 * 读取预测结果
	 * @param location
	 * @return
	 */
	public Table<Integer, Integer, Double> readResult(String location) {
		Table<Integer, Integer, Double> dataTable = HashBasedTable.create();
		
		try {
			BufferedReader br = new BufferedReader(new FileReader(new File(location)));
			String line = "";
			String[] values = null;
			while((line = br.readLine()) != null) {
				values = line.split("\t");
				dataTable.put(Integer.parseInt(values[0]), Integer.parseInt(values[1]), Double.parseDouble(values[2]));
			}
			
			br.close();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return dataTable;
	}
	
	/**
	 * 统计运行100次的MR评价预测结果并保存
	 * @param folder
	 */
	public void statisticalResult(int loop) {
		int pass = 0, failure = 0;
		double average_percent = 0;
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(new File(mainFolderStr + "/info.txt")));
			
			for(int i = 1; i <= loop; i++) {
				File file = new File(mainFolderStr + "/loop" + i + "/assertInfo.txt");
				try {
					BufferedReader br = new BufferedReader(new FileReader(file));
					String line = "";
					while((line = br.readLine()) != null) {
						if(line.contains("Assert:")) {
							if(line.split(": ")[1].equals("TRUE")){
								pass++;
								break;
							}
							else {
								failure++;
							}
						}
						if(line.contains("Percent:")) {
							average_percent += Double.parseDouble(line.split("Percent: ")[1]);
						}
					}
					br.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				
				File userfile = new File(mainFolderStr + "/loop" + i + "/train_test/userMapping.txt");
				ArrayList<String> userfileList = new ArrayList<String>();
				File itemfile = new File(mainFolderStr + "/loop" + i + "/train_test/itemMapping.txt");
				ArrayList<String> itemfileList = new ArrayList<String>();
				File mr_userfile = new File(mainFolderStr + "/loop" + i + "/mr_train_test/userMapping.txt");
				ArrayList<String> mr_userfileList = new ArrayList<String>();
				File mr_itemfile = new File(mainFolderStr + "/loop" + i + "/mr_train_test/itemMapping.txt");
				ArrayList<String>  mr_itemfileList = new ArrayList<String>();
				try {
					BufferedReader userfileBr = new BufferedReader(new FileReader(userfile));
					String line = "";
					while((line = userfileBr.readLine()) != null) {
						userfileList.add(line);
					}
					userfileBr.close();
					BufferedReader itemfileBr = new BufferedReader(new FileReader(itemfile));
					while((line = itemfileBr.readLine()) != null) {
						itemfileList.add(line);
					}
					itemfileBr.close();
					BufferedReader mr_userfileBr = new BufferedReader(new FileReader(mr_userfile));
					while((line = mr_userfileBr.readLine()) != null) {
						mr_userfileList.add(line);
					}
					mr_userfileBr.close();
					BufferedReader  mr_itemfileBr = new BufferedReader(new FileReader( mr_itemfile));
					while((line =  mr_itemfileBr.readLine()) != null) {
						 mr_itemfileList.add(line);
					}
					 mr_itemfileBr.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				int beforeUserSize = userfileList.size();
				userfileList.retainAll(mr_userfileList);
				int beforeItemSize = itemfileList.size();
				itemfileList.retainAll(mr_itemfileList);
				bw.append("loop"+ i +": userMappingNum=" + (beforeUserSize-userfileList.size()) + 
						", itemMappingNum=" +  (beforeItemSize-itemfileList.size()) + "\n");
			}
			
			bw.append(pass + ",");
			bw.append(failure + ",");
			if(failure == 0) {
				bw.append("0\n");
			}
			else {
				bw.append(average_percent/failure + "\n");
			}
			bw.close();
			
			System.out.println("\n\n\nPass:" + pass + "\n" + 
							   "Failure:" + failure);
			if(failure == 0) {
				System.out.println("Percent:0.0\n");
			}
			else {
				System.out.println("Percent:" + average_percent/failure + "\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

//	public abstract void executeafter(int loop);
	
}
