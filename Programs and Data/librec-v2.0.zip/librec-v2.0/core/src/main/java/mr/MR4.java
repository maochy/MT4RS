package mycode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;

import com.google.common.collect.Table;

/**
 * @author dazao1234
 * 
 * 操作: 随机挑选训练集中一行，该行必须在测试集中也有数据。将该行的所有评分值 + △，三角形取值范围为[1,2]
 * 评价策略: 该行的预测值应提高
 * 
 */
public class MR4 extends MR {
	
	/**
	 * 根据MR生成训练集与测试集信息
	 * @param loop
	 */
	public void execute(int loop) {
		beforeExecute(loop, "MR4");
		
		// 生成文件夹
		File train_testFolder = new File(mainFolderLoopStr + "/train_test");
		if (!train_testFolder.exists()) {
			train_testFolder.mkdirs();
		}
		saveMappingData(train_testFolder + "/userMapping.txt", userMappingData);
		saveMappingData(train_testFolder + "/itemMapping.txt", itemMappingData);
		
		// 3.根据原始训练集与测试集信息生成MR对应的训练集与测试集信息
		int chooseRowIndex = -1;
		int preferenceColumns = 0, trainColumns = 0, testColumns = 0;
		Random random = new Random();
		do {
			chooseRowIndex = random.nextInt(userMappingData.size());
			preferenceColumns = preferenceMatrix.getColumns(chooseRowIndex).size();
			trainColumns = trainMatrix.getColumns(chooseRowIndex).size();
			testColumns = testMatrix.getColumns(chooseRowIndex).size();
		}while(testColumns <= 0);
		// 生成经过变换的原始数据集
		ArrayList<String> mr_ratings = new ArrayList<String>();
		HashSet<String> trainCols = new HashSet<String>();
		for(int col : trainMatrix.getColumns(chooseRowIndex)) {
			trainCols.add(itemMappingData.get(col));
		}
		try {
			File txt = new File("../data/movielens/ml-100k/ratings.txt");
			BufferedReader txtBR = new BufferedReader(new FileReader(txt));
			String line = "";
			while((line = txtBR.readLine()) != null) {
				String[] split = line.split("\t");
				if(split[0].equals(userMappingData.get(chooseRowIndex)) && trainCols.contains(split[1])) {
					int rating = Integer.parseInt(split[2]) + random.nextInt(2) + 1;
					if(rating > 5) {
						rating = 5;
					}
					mr_ratings.add(split[0] + "\t" + split[1] + "\t" + rating);
				}
				else {
					mr_ratings.add(split[0] + "\t" + split[1] + "\t" + split[2]);
				}
			}
			txtBR.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// 生成文件夹
		File mr_train_testFolder = new File(mainFolderLoopStr + "/mr_train_test");
		if (!mr_train_testFolder.exists()) {
			mr_train_testFolder.mkdirs();
		}
		saveData(mr_train_testFolder + "/mr_ratings.txt", mr_ratings);
		saveData(mr_train_testFolder + "/mr_test.txt", testMatrix, userMappingData, itemMappingData);
		
		// 写入信息
		try {
			File file = new File(mainFolderLoopStr + "/assertInfo.txt");
			if(!file.exists()) {
				file.createNewFile();
			}
			BufferedWriter txtBW = new BufferedWriter(new FileWriter(file));
			txtBW.append("chooseRowIndex:" + userMappingData.get(chooseRowIndex) + "\n");
			txtBW.append("preferenceColumns:" + preferenceColumns + "\n" + "trainColumns:" + trainColumns + "\n" +
						 "testColumns:" + (preferenceColumns - trainColumns) + "\n");
			txtBW.append("trainColumnIDs:");
			for(int col : trainMatrix.getColumns(chooseRowIndex)) {
				txtBW.append(itemMappingData.get(col) + ",");
			}
			txtBW.append("\n");
			txtBW.append("testColumnIDs:");
			for(int col : testMatrix.getColumns(chooseRowIndex)) {
				txtBW.append(itemMappingData.get(col) + ",");
			}
			txtBW.append("\n");
			txtBW.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 根据MR的评价策略进行评价操作，判断是否通过MR
	 * @param loop
	 */
	public void assertion(int loop) {
		beforeExecute(loop, "MR4");
		
		// 生成文件夹
		File mr_train_testFolder = new File(mainFolderLoopStr + "/mr_train_test");
		if (!mr_train_testFolder.exists()) {
			mr_train_testFolder.mkdirs();
		}
		saveMappingData(mr_train_testFolder + "/userMapping.txt", userMappingData);
		saveMappingData(mr_train_testFolder + "/itemMapping.txt", itemMappingData);
		
		Table<Integer, Integer, Double> result_mr_dataTable = readResult(mainFolderLoopStr + "/result_mr.txt");
		Table<Integer, Integer, Double> result_ori_dataTable = readResult(mainFolderLoopStr + "/result_ori.txt");
		
		try{
			int chooseRowIndex = -1, testColumns = 0;
			ArrayList<Integer> testColumnIDs = new ArrayList<Integer>();
			// 读取信息
			File file = new File(mainFolderLoopStr + "/assertInfo.txt");
			BufferedReader txtBR = new BufferedReader(new FileReader(file));
			String line = "";
			while((line = txtBR.readLine()) != null) {
				if(line.contains("chooseRowIndex:")) {
					chooseRowIndex = Integer.parseInt(line.split(":")[1]);
				}
				if(line.contains("testColumns:")) {
					testColumns = Integer.parseInt(line.split(":")[1]);
				}
				if(line.contains("testColumnIDs:")) {
					String idsStr = line.split(":")[1];
					String[] ids = idsStr.split(",");
					for(String id : ids) {
						testColumnIDs.add(Integer.parseInt(id));
//						System.out.println(id);
					}
				}
			}
			txtBR.close();
			
			int count = 0;
			BufferedWriter txtBW = new BufferedWriter(new FileWriter(file, true));
			txtBW.append("\n将选中行的所有训练集评分数据 + △，△的取值范围是[1,2]，该行的预测值应提高\n");
			txtBW.append("userID\titemID\tresult_ori\t\t\tresult_mr\t\t\tresult_difference\n");
			for(int colId : testColumnIDs) {
				if(result_mr_dataTable.get(chooseRowIndex, colId) - result_ori_dataTable.get(chooseRowIndex, colId) < 0) {
					count++;
					txtBW.append(chooseRowIndex+ "\t" + 
								 colId + "\t" + 
								 result_ori_dataTable.get(chooseRowIndex, colId) + "\t\t\t" + 
								 result_mr_dataTable.get(chooseRowIndex, colId) + "\t\t\t" + 
								 (result_mr_dataTable.get(chooseRowIndex, colId) - result_ori_dataTable.get(chooseRowIndex, colId)) + "\n");
				}
			}
			
			if(count == 0) {
				txtBW.append("\nAssert: TRUE\nPercent: 0.0");
			}
			else {
				txtBW.append("\nAssert: FALSE\nPercent: " + count/(double)testColumns);
			}
			txtBW.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		if(loop == 100) {
			statisticalResult(loop);
		}
	}

}
