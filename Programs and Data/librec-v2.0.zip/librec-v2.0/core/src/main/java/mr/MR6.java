package mycode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Random;

import com.google.common.collect.Table;

/**
 * @author dazao1234
 * 
 * 操作: 随机挑选训练集中一行，使用该行数据新增一个用户
 * 评价策略: 该用户与新增用户的预测值应大致相同
 * 
 */
public class MR6 extends MR {
	
	/**
	 * 根据MR生成训练集与测试集信息
	 * @param loop
	 */
	public void execute(int loop) {
		beforeExecute(loop, "MR6");
		
		// 生成文件夹
		File train_testFolder = new File(mainFolderLoopStr + "/train_test");
		if (!train_testFolder.exists()) {
			train_testFolder.mkdirs();
		}
		saveMappingData(train_testFolder + "/userMapping.txt", userMappingData);
		saveMappingData(train_testFolder + "/itemMapping.txt", itemMappingData);
		
		// 从训练集中挑选合适的userId
		int chooseRowIndex = -1;
		int preferenceColumns = 0, trainColumns = 0, testColumns = 0;
		Random random = new Random();
		do {
			chooseRowIndex = random.nextInt(userMappingData.size());
			preferenceColumns = preferenceMatrix.getColumns(chooseRowIndex).size();
			trainColumns = trainMatrix.getColumns(chooseRowIndex).size();
			testColumns = testMatrix.getColumns(chooseRowIndex).size();
		}while(testColumns <= 0);
		
		// 获取当前最大的用户id，用于构造新用户id
		int maxId = -1;
		for(String idStr : userMappingData.values()) {
			if(maxId < Integer.parseInt(idStr)) {
				maxId = Integer.parseInt(idStr);
			}
		}
		
		// 生成经过变换的原始数据集
		ArrayList<String> mr_ratings = new ArrayList<String>();
		try {
			File txt = new File("../data/movielens/ml-100k/ratings.txt");
			BufferedReader txtBR = new BufferedReader(new FileReader(txt));
			String line = "";
			while((line = txtBR.readLine()) != null) {
				String[] split = line.split("\t");
				mr_ratings.add(split[0] + "\t" + split[1] + "\t" + split[2]);
			}
			txtBR.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		for(int preferenceItemId : preferenceMatrix.getColumns(chooseRowIndex)) {
			mr_ratings.add((maxId+1) + "\t" + 
							  itemMappingData.get(preferenceItemId) + "\t" + 
							  preferenceMatrix.get(chooseRowIndex, preferenceItemId));
		}
		
		// 生成文件夹
		File mr_train_testFolder = new File(mainFolderLoopStr + "/mr_train_test");
		if (!mr_train_testFolder.exists()) {
			mr_train_testFolder.mkdirs();
		}
		saveData(mr_train_testFolder + "/mr_ratings.txt", mr_ratings);
		saveData(mr_train_testFolder + "/mr_test.txt", testMatrix, userMappingData, itemMappingData);
		
		// 根据选出的行构造新用户，分别将数据写入测试集
		try {
			BufferedWriter mr_testBW = new BufferedWriter(new FileWriter(new File(mr_train_testFolder + "/mr_test.txt"), true));
			for(int testItemId : testMatrix.getColumns(chooseRowIndex)) {
				mr_testBW.append((maxId+1) + "\t" + 
						  itemMappingData.get(testItemId) + "\t" + 
						  testMatrix.get(chooseRowIndex, testItemId) + "\n");
			}
			mr_testBW.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// 保存信息
		try {
			File file = new File(mainFolderLoopStr + "/assertInfo.txt");
			if(!file.exists()) {
				file.createNewFile();
			}
			BufferedWriter txtBW = new BufferedWriter(new FileWriter(file));
			txtBW.append("chooseRowIndex:" + userMappingData.get(chooseRowIndex) + "\n");
			txtBW.append("newRowIndex:" + (maxId + 1) + "\n");
			txtBW.append("preferenceColumns:" + preferenceColumns + "\n" + "trainColumns:" + trainColumns + "\n" +
						 "testColumns:" + (preferenceColumns - trainColumns) + "\n");
			txtBW.append("trainColumnIDs:");
			for(int col : trainMatrix.getColumns(chooseRowIndex)) {
				txtBW.append(itemMappingData.get(col) + ",");
			}
			txtBW.append("\n");
			txtBW.append("testColumnIDs:");
			for(int col : testMatrix.getColumns(chooseRowIndex)) {
				txtBW.append(itemMappingData.get(col) + ",");
			}
			txtBW.append("\n");
			txtBW.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}

	/**
	 * 根据MR的评价策略进行评价操作，判断是否通过MR
	 * @param loop
	 */
	public void assertion(int loop) {
		beforeExecute(loop, "MR6");
//		setMainFolderStr(loop, "MR6");
		
		// 生成文件夹
		File mr_train_testFolder = new File(mainFolderLoopStr + "/mr_train_test");
		if (!mr_train_testFolder.exists()) {
			mr_train_testFolder.mkdirs();
		}
		saveMappingData(mr_train_testFolder + "/userMapping.txt", userMappingData);
		saveMappingData(mr_train_testFolder + "/itemMapping.txt", itemMappingData);
		
		Table<Integer, Integer, Double> result_mr_dataTable = readResult(mainFolderLoopStr + "/result_mr.txt");
		
		try{
			int chooseRowIndex = -1, newRowIndex = -1, testColumns = 0;
			ArrayList<Integer> testColumnIDs = new ArrayList<Integer>();
			
			File file = new File(mainFolderLoopStr + "/assertInfo.txt");
			BufferedReader txtBR = new BufferedReader(new FileReader(file));
			
			String line = "";
			while((line = txtBR.readLine()) != null) {
				if(line.contains("chooseRowIndex:")) {
					chooseRowIndex = Integer.parseInt(line.split(":")[1]);
				}
				if(line.contains("newRowIndex:")) {
					newRowIndex = Integer.parseInt(line.split(":")[1]);
				}
				if(line.contains("testColumns:")) {
					testColumns = Integer.parseInt(line.split(":")[1]);
				}
				if(line.contains("testColumnIDs:")) {
					String idsStr = line.split(":")[1];
					String[] ids = idsStr.split(",");
					for(String id : ids) {
						testColumnIDs.add(Integer.parseInt(id));
					}
				}
			}
			txtBR.close();
			
			int count = 0;
			BufferedWriter txtBW = new BufferedWriter(new FileWriter(file, true));
			txtBW.append("\n增加一个完全相同的用户，这两个用户的预测值应该大致相同\n\n");
			txtBW.append("userID\tnewUserID\titemID\tresult_ori\t\t\tresult_new\t\t\tori-new_result\n");
			for(int colId : testColumnIDs) {
				if(Math.abs(result_mr_dataTable.get(chooseRowIndex, colId) - result_mr_dataTable.get(newRowIndex, colId)) > 0.1) {
//				if(result_mr_dataTable.get(chooseRowIndex, colId) - result_mr_dataTable.get(newRowIndex, colId) != 0) {
					count++;
					txtBW.append(chooseRowIndex+ "\t" + 
								 newRowIndex+ "\t\t" + 
								 colId + "\t" + 
								 result_mr_dataTable.get(chooseRowIndex, colId) + "\t\t" + 
								 result_mr_dataTable.get(newRowIndex, colId) + "\t\t\t" + 
								 Math.abs(result_mr_dataTable.get(chooseRowIndex, colId) - result_mr_dataTable.get(newRowIndex, colId)) + "\n");
				}
			}
			
			if(count == 0) {
				txtBW.append("\nAssert: TRUE\nPercent: 0.0");
			}
			else {
				txtBW.append("\nAssert: FALSE\nPercent: " + count/(double)testColumns);
			}
			txtBW.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		if(loop == 100) {
			statisticalResult(loop);
		}
	}
	
}
