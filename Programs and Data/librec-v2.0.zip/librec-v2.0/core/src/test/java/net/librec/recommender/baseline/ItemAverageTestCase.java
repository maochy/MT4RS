/**
 * Copyright (C) 2016 LibRec
 * 
 * This file is part of LibRec.
 * LibRec is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * LibRec is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with LibRec. If not, see <http://www.gnu.org/licenses/>.
 */
package net.librec.recommender.baseline;

import net.librec.BaseTestCase;
import net.librec.common.LibrecException;
import net.librec.conf.Configuration;
import net.librec.conf.Configuration.Resource;
import net.librec.job.RecommenderJob;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;

/**
 * Item Average Test Case correspond to ItemAverageRecommender
 * {@link net.librec.recommender.baseline.ItemAverageRecommender}
 * 
 * @author liuxz
 */
public class ItemAverageTestCase extends BaseTestCase {

	@Override
	@Before
	public void setUp() throws Exception {
		super.setUp();
	}

	/**
	 * Test the whole process of Item Average Recommender
	 * 
	 * @throws ClassNotFoundException
	 * @throws LibrecException
	 * @throws IOException
	 */
	@Test
	public void testRecommender() throws ClassNotFoundException, LibrecException, IOException {
		Resource resource = new Resource("rec/baseline/itemaverage-test.properties");
		
//		String splitterModel = "ratio";
		String splitterModel = "testset";
		
		exe(resource, splitterModel, "MR1");
//		exe(resource, splitterModel, "MR2");
//		exe(resource, splitterModel, "MR3");
//		exe(resource, splitterModel, "MR4");
//		exe(resource, splitterModel, "MR5");
//		exe(resource, splitterModel, "MR6");
		
	}
	
	public void exe(Resource resource, String splitterModel, String mrID) throws ClassNotFoundException, LibrecException, IOException {
		for(int i = 1; i <= 100; i++) {
			System.gc();
			conf = new Configuration();
			conf.addResource(resource);
			conf.set("data.model.splitter", splitterModel);
			
			RecommenderJob job = new RecommenderJob(conf, mrID);
			job.runJob(i);
		}
	}

}
