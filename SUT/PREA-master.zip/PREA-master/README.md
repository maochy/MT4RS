PREA
====

PREA for the comparative evaluation to MGBR.
