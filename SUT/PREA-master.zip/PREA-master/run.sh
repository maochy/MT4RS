java -Xmx6g -classpath build/classes:ujmp-complete-0.2.5.jar prea.main.Prea -f bi/movieLens100K_BI -s pred bi/movieLens100K_BI_testset_of_fold1.txt
